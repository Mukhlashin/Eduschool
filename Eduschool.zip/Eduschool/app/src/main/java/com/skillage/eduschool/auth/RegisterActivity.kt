package com.skillage.eduschool.auth

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.skillage.eduschool.R

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
    }
}